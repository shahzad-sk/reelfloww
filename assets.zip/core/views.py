
from django.shortcuts import render, redirect, get_object_or_404
from .models import Video, Comment, Rating, User
from .forms import CreatorVideoUploadForm, ConsumerSignupForm, CommentForm, RatingForm
from django.contrib.auth import login,authenticate
from django.contrib.auth.views import LoginView
from django.db.models import Q
from django.http import HttpResponseForbidden

def index(request):
    user_has_account = False
    if request.method == "POST" and "email" in request.POST:
        user_has_account = User.objects.filter(email=request.POST["email"]).exists()
    return render(request , 'home.html',{'user_has_account': user_has_account})
def about(request):
    return render(request,'core/about_us.html')
# Consumer Signup
def consumer_signup(request):
    if request.method == 'POST':
        form = ConsumerSignupForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_consumer = True
            user.is_active = True
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect('video_list')
    else:
        form = ConsumerSignupForm()
         
    return render(request, 'core/consumer_signup.html', {'form': form})

def creator_dashboard(request):
    return render(request, 'core/creator_dashboard.html')

# Creator Video Upload
def upload_video(request):
    if request.method == 'POST':
        form = CreatorVideoUploadForm(request.POST, request.FILES)
        if form.is_valid():
            video = form.save(commit=False)
            video.creator = request.user
            video.hashtags = request.POST.get('hashtags', '')
            video.save()
            return redirect('creator_dashboard')
        else:
            print(form.errors)  # Add this line to print any form errors
    else:
        form = CreatorVideoUploadForm()
    return render(request, 'core/upload_video.html', {'form': form})


# Video List and Detail
# def video_list(request):
#     search_query = request.GET.get('search', '')
#     videos = Video.objects.all()

#     if search_query:
#         videos = videos.filter(
#             title__icontains=search_query
#         ) | videos.filter(
#             hashtags__name__icontains=search_query
#         ).distinct()
#     return render(request, 'core/video_list.html', {'videos': videos})
from django.shortcuts import render
from django.db.models import Q, Case, When, Value, IntegerField
from .models import Video
def video_list(request):

    if not request.user.is_authenticated:
        return redirect('login')
    search_query = request.GET.get('search', '')
    
    
    if search_query:
        # Annotate all videos, prioritize matching ones
        videos = Video.objects.annotate(
            search_priority=Case(
                When(Q(title__icontains=search_query) | Q(hashtags__icontains=search_query), then=Value(1)),
                default=Value(0),
                output_field=IntegerField()
            )
        ).order_by('-search_priority', '-uploaded_at')  # First by priority, then by upload date
    else:
        # If no search query, just fetch all videos ordered by uploaded date
        videos = Video.objects.all().order_by('-uploaded_at')

    for video in videos:
         if video.hashtags:
            video.hashtags = [hashtag.strip() for hashtag in video.hashtags.split(',') if hashtag.strip()] 
        



    return render(request, 'core/video_list.html', {'videos': videos})





def video_detail(request, pk):
    video = get_object_or_404(Video, pk=pk)
    has_liked = video.likes.filter(id=request.user.id).exists()
    comments = video.comments.all()
    ratings = video.ratings.all()
    comment_form = CommentForm()
    rating_form = RatingForm()
    
    next_video = Video.objects.filter(id__gt=video.id).first()
    prev_video = Video.objects.filter(id__lt=video.id).last()
    
    if video.hashtags:
            video.hashtags = [hashtag.strip() for hashtag in video.hashtags.split(',') if hashtag.strip()] 
    return render(request, 'core/video_detail.html', {
        'video': video,
        'comments': comments,
        'ratings': ratings,
        'comment_form': comment_form,
        'rating_form': rating_form,
        'next_video': next_video,
        'prev_video': prev_video,
        'has_liked': has_liked
    })

# Add Comment
def add_comment(request, pk):
    video = get_object_or_404(Video, pk=pk)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.user = request.user
            comment.video = video
            comment.save()
            return redirect('video_detail', pk=pk)

# Add Rating
def add_rating(request, pk):
    video = get_object_or_404(Video, pk=pk)
    if request.method == 'POST':
        form = RatingForm(request.POST)
        if form.is_valid():
            rating = form.save(commit=False)
            rating.user = request.user
            rating.video = video
            rating.save()
            return redirect('video_detail', pk=pk)

class CustomLoginView(LoginView):
    template_name = 'core/login.html'  # Make sure this points to the correct login template

    def form_valid(self, form):
        # After successful authentication, we can redirect to the appropriate page
        user = form.get_user()
        if user.is_active:
            login(self.request, user)
            if user.is_creator:
        
               return redirect('creator_dashboard')  # Redirect to creator dashboard if creator
            else:
                return redirect('video_list') 
        else:
            form.add_error(None, 'This account is inactive.')
            return self.form_invalid(form)# Or another page for consumers

    def form_invalid(self, form):
        # If form is invalid, return to login page with error
        return super().form_invalid(form)

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

@csrf_exempt
def like_video(request, video_id):
    if not request.user.is_authenticated:
        return JsonResponse({'success': False, 'message': 'Authentication required.'}, status=403)

    try:
        video = Video.objects.get(id=video_id)
    except Video.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'Video not found.'}, status=404)

    if request.user in video.likes.all():
        video.likes.remove(request.user)
        liked = False
    else:
        video.likes.add(request.user)
        liked = True

    return JsonResponse({'success': True, 'liked': liked, 'likes': video.likes.count()})
def creator_video_list(request):
    # Ensure the user is authenticated
    if not request.user.is_authenticated:
        return redirect('login')  # Redirect to login if the user is not authenticated

    # Ensure the user is a creator
    if not request.user.is_creator:
        return HttpResponseForbidden("You do not have permission to view this page.")  # Return forbidden if not a creator

    # Debugging: Print the logged-in user and check if they are a creator
    print(f"Logged-in user: {request.user.username} (Is Creator: {request.user.is_creator})")

      # Get the search query if provided
    videos = Video.objects.filter(creator=request.user).order_by('-uploaded_at')
    # Fetch videos uploaded by the logged-in creator
    

    # Process hashtags (optional, based on your need)
    for video in videos:
        if video.hashtags:
            video.hashtags = [hashtag.strip() for hashtag in video.hashtags.split(',') if hashtag.strip()]

    return render(request, 'core/my_list.html', {'videos': videos})

# from django.contrib.auth.mixins import LoginRequiredMixin
# from django.shortcuts import render
# from django.http import HttpResponseForbidden
# from django.views.generic import ListView
# from .models import Video
# class CreatorVideoListView(LoginRequiredMixin, ListView):
#     model = Video
#     template_name = 'core/my_list.html'

#     def get_queryset(self):
#         search_query = self.request.GET.get('search', '')
#         user = self.request.user  # This will now safely refer to the logged-in user

#         if search_query:
#             # Annotate and order videos
#             videos = Video.objects.filter(creator=user).annotate(
#                 search_priority=Case(
#                     When(Q(title__icontains=search_query) | Q(hashtags__icontains=search_query), then=Value(1)),
#                     default=Value(0),
#                     output_field=IntegerField()
#                 )
#             ).order_by('-search_priority', '-uploaded_at')
#         else:
#             # Fetch videos uploaded by the logged-in creator
#             videos = Video.objects.filter(creator=user).order_by('-uploaded_at')

#        return videos


from django.contrib.auth import logout
from django.shortcuts import redirect

def logout_view(request):
    logout(request)
    request.session.flush()  # Clear session data
    return redirect('login')   # Redirect to login page after logout

